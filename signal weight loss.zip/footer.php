<hr class="footer-hr"/>

<div class="row copyright">
    <img class="logo" src="<?php bloginfo('template_directory'); ?>/images/logo.png" alt="logo"/>
        <span class="text-muted copy-text">
            2014 Atlantic Pacific Media, LLC. All rights reserved.
        </span>
    <a href="#" class="copy-terms">TERMS</a>
    <span>|</span>
    <a href="#" class="copy-privacy">PRIVACY</a>
    <div class="made-with-love pull-right">
        MADE WITH
        <img src="<?php bloginfo('template_directory'); ?>/images/heart.png" alt="love"/>
        IN LA
    </div>
    <img src="<?php bloginfo('template_directory'); ?>/images/billassure.png" alt="bill assure" class="assure"/>
</div> <!-- COPY ROW -->


</div><!---Container--->

<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $('#tabs').tab();
    });
</script>

<?php wp_footer(); ?>
</body>

</html>