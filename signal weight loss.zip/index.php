<?php get_header(); ?>
    <div class="content">
        <div class="row">

            <div class="first-section">
                <div class="photos col-md-4">
                    <img src="images/photo2.png" alt="before" class="photo-before"/>
                    <img src="images/photo1.png" alt="after" class="photo-after"/>
                    <div class="lost-lbs">
                        <p>Kristin</p><br>
                        <p>lost</p><br>
                        <p>58 lbs</p>
                    </div>
                    <div class="comment-panel">
                        <p class="comment">
                            <span>The Signal Weight Loss pill</span> <br>
                            <span>changed my life forever!</span>
                        </p>
                        <p class="comment-author">
                            <span class="name">- Kristin MacDowell</span>
                            <span class="founder">Founder & Nutritionist</span>
                        </p>
                    </div>
                </div>
                <div class="loose-weight col-md-4">
                    <img src="images/Lose-weight.png" alt="loose weight" class="loose-weight-img"/>
                    <p class="text-center loose-weight-subheader">Eat foods you love and still lose weight.<br>
                        Try Signal to control hunger cravings, and see<br> instant results.</p>
                    <p class="try-it">TRY SIGNAL+ FOR FREE!</p>
                    <p class="backed">Backed by a 30-Day Satisfaction Guarantee</p>
                </div>
                <div class="pills col-md-4">
                    <img src="images/pills.png" alt="pills-box" class="pills-small left"/>
                    <img src="images/pills.png" alt="pills-box"/>
                    <img src="images/pills.png" alt="pills-box" class="pills-small right"/>
                    <img src="images/NEW.png" alt="NEW!" class="image-new"/>
                    <a href="#" class="click-here"></a>
                </div>
            </div>

        </div>

        <div class="row features">
            <div class="col-md-4">
                <div class="feature hunger">
                    <div class="feature-header">
                        <h3>Control Your Hunger</h3>
                    </div>
                    <div class="feature-body">Signal your body to<br> eat less with one<br> powerful, little pill.</div>
                    <a href="#" class="read-more-link">Read more</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature ingridients">
                    <div class="feature-header">
                        <h3>all-natural ingredients</h3>
                    </div>
                    <div class="feature-body">Supercharge your<br>
                        metabolism with key<br>
                        plant-based, whole-food nutrients.</div>
                    <a href="#" class="read-more-link">Read more</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature support">
                    <div class="feature-header">
                        <h3>community support</h3>
                    </div>
                    <div class="feature-body">Get 1-on-1 motivational<br>
                        guidance from professional<br>
                        nutritionists, share skinny<br>
                        recipes and food photos.</div>
                    <a href="#" class="read-more-link">Read more</a>
                </div>
            </div>
        </div>

        <div class="row navigtion-tabs col-md-12">
            <ul class="nav nav-tabs" data-tabs="tabs">
                <li class="active"><a data-toggle="tab" href="#first"><i class="glyphicon glyphicon-plus"></i> How Signal Works</a></li>
                <li><a data-toggle="tab" href="#second"><i class="glyphicon glyphicon-plus"></i> What’s in Signal</a></li>
                <li><a data-toggle="tab" href="#third"><i class="glyphicon glyphicon-plus"></i> Signal Success Stories</a></li>
            </ul>
        </div>

        <div class="row tabs col-md-12">

            <div class="tab-content">

                <div class="first-tab tab-pane active" id="first">
                    <h1>Signal Stops Hunger and starts rapid weight loss</h1>
                    <div class="col-md-3 overeating">
                        <img src="images/stop.png" alt="stop!" class="start-img"/>
                        <h4 class="action-subheader"><b class="stop">STOP</b> OVEREATING</h4>
                        <p class="text-center">Get that same “full’’ feeling while your body craves less food.</p>
                    </div>
                    <div class="col-md-3 hunger">
                        <img src="images/stop.png" alt="stop!" class="start-img"/>
                        <h4 class="action-subheader"><b class="stop">STOP</b> HUNGER</h4>
                        <p class="text-center">Signal alerts the brain that you’ve already eaten.</p>
                    </div>
                    <div class="col-md-3 learning">
                        <img src="images/start.png" alt="start!" class="stop-img"/>
                        <h4 class="action-subheader"><b class="start">START</b> LEARNING</h4>
                        <p>Our proven method identifies the right foods that trick your body into losing weight.</p>
                    </div>
                    <div class="col-md-3 losing">
                        <img src="images/start.png" alt="start!" class="stop-img"/>
                        <h4 class="action-subheader"><b class="start">START</b> LOSING</h4>
                        <p>Give your body the essential signal that turns hunger off and fat-burning on.</p>
                    </div>
                </div>

                <div class="second-tab tab-pane" id="second">
                    <h1 class="second-tab-header">SYNERGISTIC BLEND OF <b>POWERFUL</b> <br> <b>HUNGER-FIGHTING</b> INGREDIENTS </h1>

                    <div class="ingridients">
                        <img src="images/superfoods.png" alt="superfoods" class="superfoods"/>
                    </div>
                    <div class="no">
                        <img src="images/no.png" alt="no" class="no-img"/>
                        <img src="images/chemicals.png" alt="text" class="text"/>
                        <!--<h2 class="no-text">CHEMICALS,<br/>
                            DRUGS, DIURETICS<br/>
                            SIMULANTS<br/>
                            CALORIE-COUNTING<br/>
                            PRE-PACKAGED FOODS</h2>-->
                    </div>
                    <div class="img-table">
                        <img src="images/icons-table.png" alt="img-table"/>
                    </div>
                </div>

                <div class="third-tab tab-pane" id="third">

                    <div class="success-story kristin">
                        <div class="story">
                            <img src="images/banner.png" alt="banner" class="banner"/>
                            <p class="story-text">
                                I thought there was absolutely no hope to ever be skinny. Then I discovered The Signal Method and
                                developed a very powerful pill that changed my life!  For over 10 years, I've maintained a perfect size 2
                                effortlessly while eating a ton of delicious foods with little to no exercise.
                            </p>
                            <p class="comment-author">
                                <span class="name">- Kristin MacDowell</span>
                                <span class="founder">Founder & Nutritionist</span>
                            </p>
                        </div>
                        <div class="story-photos">
                            <img src="images/kristin-before.png" alt="before" class="photo-before"/>
                            <img src="images/kristin-after.png" alt="kristin-after" class="photo-after"/>
                        </div>
                    </div>

                    <div class="success-story jeanette">
                        <div class="story-photos pull-left">
                            <img src="images/jeanette-before.png" alt="before" class="photo-before"/>
                            <img src="images/jeanette-after.png" alt="kristin-after" class="photo-after"/>
                        </div>
                        <div class="story pull-right">
                            <p class="story-text">
                                My family has a long history of obesity, and that's the road I was heading down. I just thought older people were fat. Period! Once I shifted my lifestyle by adopting The Signal Method and taking The Signal Weight Loss Pill, everything I ever thought about healthy living was turned upside down. Over a period of 6 months, I went from a size 10 to a size 2! It even helped me lose the final
                                10 lbs—the most difficult 10 to lose!

                            </p>
                            <p class="comment-author">
                                <span class="name">- Jeanette K.</span>
                            </p>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div><!-- CONTENT ROW -->

    <div class="row">
        <div class="col-md-12">
            <footer>
                <div class="pills">
                    <img src="images/pills.png" alt="pills-box" class="pills-small left"/>
                    <img src="images/pills.png" alt="pills-box"/>
                    <img src="images/pills.png" alt="pills-box" class="pills-small right"/>
                    <a href="#" class="click-here"></a>
                </div>
                <img src="images/30-day.png" alt="30 days promo" class="thirty-days-promo"/>
                <img src="images/Online%20offer_%20TRY%20IT%20FREE.png" alt="try it free" class="try-it-free"/>

                <div class="socials col-md-10">
                    <ul>
                        <li><a href="#"><i class="social-icon inst"></i></a>Instagram </li>
                        <li><a href="#"><i class="social-icon fb"></i></a>Facebook</li>
                        <li><a href="#"><i class="social-icon tw"></i></a>Twitter</li>
                        <li><a href="#"><i class="social-icon pin"></i></a>Pinterest</li>
                        <li><a href="#"><i class="social-icon g"></i></a>Google+</li>
                        <li><a href="#"><i class="social-icon blog"></i></a>Blog</li>
                        <li><a href="#"><i class="social-icon contact"></i></a>Contact</li>
                    </ul>
                </div>
            </footer>
        </div>
    </div><!-- FOOTER ROW -->

    <hr class="footer-hr"/>

    <div class="row copyright">
        <img class="logo" src="images/logo.png" alt="logo"/>
        <span class="text-muted copy-text">
            2014 Atlantic Pacific Media, LLC. All rights reserved.
        </span>
        <a href="#" class="copy-terms">TERMS</a>
        <span>|</span>
        <a href="#" class="copy-privacy">PRIVACY</a>
        <div class="made-with-love pull-right">
            MADE WITH
            <img src="images/heart.png" alt="love"/>
            IN LA
        </div>
        <img src="images/billassure.png" alt="bill assure" class="assure"/>
    </div> <!-- COPY ROW -->


    </div><!---Container--->
    <!-- DESKTOP END -->

    <!-- MOBILE BEGIN -->

    <div class="container-fluid mobile">

        <div class="banner">
            <img src="images/mobile/header/banner.png" alt="banner"/>
            <a href="#"><img src="images/mobile/header/try-it.png" alt="try-it" class="try-it"/></a>
            <p class="guarantee">100% SATISFACTION GUARANTEE</p>
        </div>

        <div class="panel-group" id="accordion">
            <div class="panel panel-default how-it-works">

                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                            <i class="glyphicon glyphicon-plus"></i>How Signal Works
                        </a>
                    </h4>
                </div>

                <div id="collapseOne" class="panel-collapse collapse in">
                    <div class="panel-body">
                        <h3 class="blue-text text-center">SIGNAL STOPS HUNGER<br> <b>IN ITS TRACKS</b></h3>
                        <div class="col-xs-12 overeating">
                            <img src="images/overeating.png" alt="overeating"/>
                            <div class="col-xs-7">
                                <h4 class="action-subheader"><b class="stop">STOP</b> OVEREATING</h4>
                                <p>Get that same “full’’ feeling while your body craves less food.</p>
                            </div>
                        </div>
                        <div class="col-xs-12 hunger">
                            <img src="images/hunger.png" alt="hunger"/>
                            <div class="col-xs-7">
                                <h4 class="action-subheader"><b class="stop">STOP</b> HUNGER</h4>
                                <p>Signal alerts the brain that you’ve already eaten.</p>
                            </div>
                        </div>
                        <div class="col-xs-12 learning">
                            <img src="images/learning.png" alt="learning"/>
                            <div class="col-xs-7">
                                <h4 class="action-subheader"><b class="start">START</b> LEARNING</h4>
                                <p>Our proven method identifies the right foods that trick your body into losing weight.</p>
                            </div>
                        </div>
                        <div class="col-xs-12 losing">
                            <img src="images/losing.png" alt="losing"/>
                            <div class="col-xs-7">
                                <h4 class="action-subheader"><b class="start">START</b> LOSING</h4>
                                <p>Give your body the essential signal that turns hunger off and fat-burning on.</p>
                            </div>
                        </div>

                        <img src="images/mobile/lose-it.png" alt="lose it" class="loseIt"/>
                        <div class="try-it-section">
                            <h4>Diets Restrict,<br/>
                                We Replace.</h4>
                            <a href="#"><img src="images/mobile/header/try-it.png" alt="try-it" class="try-it"/></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel panel-default whatsIn">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                            <i class="glyphicon glyphicon-plus"></i>What’s in Signal
                        </a>
                    </h4>
                </div>
                <div id="collapseTwo" class="panel-collapse collapse">
                    <div class="panel-body">
                        <img src="images/superfoods.png" alt="superfoods" class="superfoods"/>
                        <img src="images/mobile/synergistic.png"/>
                        <img src="images/mobile/ingridients-1.png"/>
                        <img src="images/mobile/ingridients-2.png"/>
                        <img src="images/mobile/ingridients-3.png" class="ingridients-3"/>
                        <img src="images/mobile/no.png" alt="no" class="no-img"/>
                        <div class="stop-waiting">
                            <a href="#"><img src="images/mobile/header/try-it.png" alt="try-it" class="try-it"/></a>
                            <img src="images/mobile/stop-waiting-bg.png" alt="stop waiting" class="img-responsive"/>
                        </div>
                    </div>
                </div>
            </div>


            <div class="panel panel-default stories">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                            <i class="glyphicon glyphicon-plus"></i>Signal Success
                        </a>
                    </h4>
                </div>
                <div id="collapseThree" class="panel-collapse collapse">
                    <div class="panel-body">
                        <div class="success-story kristin">
                            <div class="story-photos">
                                <img src="images/mobile/before-after-kristin.png"/>
                            </div>
                            <div class="story">
                                <p class="story-text text-center">
                                    "I thought there was absolutely no hope to ever be skinny. Then I discovered The Signal Method and
                                    developed a very powerful pill that changed my life!  For over 10 years, I've maintained a perfect size 2
                                    effortlessly while eating a ton of delicious foods with little to no exercise."
                                    <br/>
                                    <span class="name pull-right">- Kristin MacDowell, Founder & Nutritionist</span>
                                </p>
                            </div>
                        </div>

                        <div class="success-story laurine">
                            <div class="story-photos">
                                <img src="images/mobile/before-after-laurine.png"/>
                            </div>
                            <div class="story">
                                <p class="story-text text-center">
                                    "When I take the Signal Pill and practice the Signal Method, the pounds literally melt off. I can go from feeling self conscious to bikini ready in just a few days. It even helped me look ultra fabulous on my wedding day!"
                                    <br/>
                                    <span class="name pull-right">- Lauren F.</span>
                                </p>
                            </div>
                        </div>

                        <div class="success-story jeanette">
                            <div class="story-photos">
                                <img src="images/mobile/before-after-jeanette.png"/>
                            </div>
                            <div class="story">
                                <p class="story-text text-center">
                                    "When I began taking The Signal Pill and practicing The Signal Method, I was able to reset my palate and shrink my stomach within a few weeks. Nothing feels better than freedom from a fat suit!"                                <br/>
                                    <span class="name pull-right">- Jeanette K.</span>
                                </p>
                            </div>
                        </div>
                        <div class="stop-waiting">
                            <a href="#"><img src="images/mobile/header/try-it.png" alt="try-it" class="try-it"/></a>
                            <img src="images/mobile/stop-waiting-text.png" alt="stop waiting" class="img-responsive stop-text"/>
                            <img src="images/mobile/stop-waiting-bg.png" alt="stop waiting" class="img-responsive"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="mobile-footer col-xs-10 col-xs-offset-1 text-center">
            <p>Risk-Free 30-Day Trial!* Signal Weight Loss has a 100% success rate for those who follow the Signal Method.
                Average weight loss for those followers can be up to 20 lbs in 2 months without exercise. The Signal Method
                advocates a healthy lifestyle on an all-you-can-eat diet. It's the only weight-loss program with long-term, lasting results!</p>
        </div>
    </div>

    <?php get_footer(); ?>