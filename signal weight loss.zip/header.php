<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Signal weight loss</title>
    <link rel="stylesheet" href="style.css" type="text/css"/>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <?php wp_head(); ?>
</head>


<body>

<div class="container">
    <div class="row">
        <header>
            <nav class="navbar navbar-default" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header ">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"><img src="images/logo.png" class="navbar-logo"/></a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li class="dropdown why-signal-works">
                                <a href="/why-signal-works" class="dropdown-toggle" data-toggle="dropdown">Why Signal Works</a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="/how-it-works">How it works</a></li>
                                    <li><a href="/ingredients">Ingredients</a></li>
                                    <li><a href="/community-support">Community support</a></li>
                                </ul>
                            </li>
                            <li class="dropdown success-stories">
                                <a href="/success-stories" class="dropdown-toggle" data-toggle="dropdown">Success stories</a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="/real-results">Real results</a></li>
                                    <li><a href="/meet-our-founder">Meet our founder</a></li>
                                </ul>
                            </li>

                            <li class="dropdown">
                                <a href="/get-support" class="dropdown-toggle" data-toggle="dropdown">Get support</a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="/contact-us">Contact us</a></li>
                                    <li><a href="/faq">Faq</a></li>
                                    <li><a href="/email-sign-up">Email sign up</a></li>
                                </ul>
                            </li>
                            <li class="my-signal"><a href="/my-signal" class="dropdown-toggle" data-toggle="dropdown"><i class="signal-icon"></i>My signal</a></li>
                        </ul>

                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
            </nav>
        </header>
        <hr>
    </div><!-- HEADER ROW -->